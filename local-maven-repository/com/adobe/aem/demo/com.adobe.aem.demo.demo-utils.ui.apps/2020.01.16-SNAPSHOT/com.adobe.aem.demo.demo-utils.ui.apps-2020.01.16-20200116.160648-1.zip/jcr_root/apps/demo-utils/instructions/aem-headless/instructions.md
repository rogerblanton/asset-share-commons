<div class="aem-logo"></div>
<div class="adobe-logo"></div>

# AEM Headless

The AEM Headless demo showcases how AEM can be used to expose content via HTTP APIs as JSON for consumption by native Mobile Apps; In this case an Android App, however any Mobile App platform (ex. iOS) could be built following the same approaches.

The use of Android is because it has a cross-platform emulator that all users (Windows, macOS, and Linux) of this demo can use to run the native App.

_This demo is a by-product of the [Getting Started with AEM Headless](https://docs.adobe.com/content/help/en/experience-manager-learn/getting-started-with-aem-headless/overview.html) Tutorial._

## Overview video

<iframe width="854" height="480" src="https://video.tv.adobe.com/v/28315?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

## Value proposition

> A NOTE ABOUT POSITIONING: While this approach can be used to power ANY programmatic consumer, including SPA's, Adobe recommends using AEM SPA Editor as the first choice for any SPA-related use-case.
This demo specifically targets a native Mobile App to help draw the clear distinction of when to use AEM Content Services (Pages with Components that are serialized to JSON and consumed via custom code) and AEM SPA Editor to support the creation of SPAs.

This demo shows how AEM supports managing content centrally in AEM and syndicating it in a Headless fashion to a native Android Mobile App.

This demo is a specific use-case in the larger [Hybrid CMS story](/apps/demo-utils/instructions/hybrid-cms.html) that focuses re-using content specifically in the Mobile App channel.
We explore how AEM supports the rapid creation of a HTTP API, that allows for authors to specific and author the content the API exposes.

At a high-level this demo shows:

* Content that represent an Event using Content Fragments
* AEM Content Services end-points using AEM Sites' Templates and Pages that expose the Event data as JSON
* AEM WCM Core Components can be used to enable marketers to author JSON end-points
* Consume AEM Content Services JSON from an Mobile App

## Downloads

### AEM Content Packages

_Install via AEM Package Manager on __BOTH__ AEM Author and Publish_

* <a href="https://link.enablementadobe.com/aem-headless_all-package" target="_blank" class="button">com.adobe.aem.guides.wknd-mobile.all-x.x.x.zip</a>

### Android Mobile App

* <a href="http://link.enablementadobe.com/aem-headless_mobile-app" target="_blank" class="button">wknd-mobile.x.x.x.apk</a>
* <a href="https://developer.android.com/studio" class="button">Android Studio</a>


## Set up Instructions

1. Install `com.adobe.aem.guides.wknd-mobile.all-x.x.x.zip` on [AEM Author via Package Manager](http://localhost:4502/crx/packmgr/index.jsp)
1. Install `com.adobe.aem.guides.wknd-mobile.all-x.x.x.zip` on [AEM Publish via Package Manager](http://localhost:4503/crx/packmgr/index.jsp)
1. Download [Android Studio](https://developer.android.com/studio)
1. Set-up the Android Studio and run the Mobile App (`wknd-mobile.x.x.x.apk`) in the Android Emulator. Watch the video below, or follow the [text instructions](https://docs.adobe.com/content/help/en/experience-manager-learn/getting-started-with-aem-headless/chapter-7.html#running-the-mobile-app-locally).

   <iframe width="854" height="480" src="https://video.tv.adobe.com/v/28341?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen
   mozallowfullscreen allowfullscreen scrolling="no"></iframe>

1. If running AEM Publish on something other than `http://localhost:4503`, follow the instructions for [configuring the Mobile App for non-localhost use](https://docs.adobe.com/content/help/en/experience-manager-learn/getting-started-with-aem-headless/chapter-7.html#configuring-the-mobile-app-for-non-localhost-use).
The Mobile App __must__ source content from AEM Publish, as AEM Author does not allow un-authenticated access to its content.

## Reviewing the JSON End-points

The WKND Mobile app accesses the JSON via AEM Publish at:

* [http://localhost:4503/content/wknd-mobile/en/api/events.model.json](http://localhost:4503/content/wknd-mobile/en/api/events.model.json)

This is the AEM Content Services rendition of the page, invoked via the `.model.json` selector and extension on the URL. AEM Content Services walks the Page's components, and serializes them JSON conforming to the AEM Content Services JSON schema.
All AEM WCM Core Components are AEM Content Services compatible, and any Custom Components can be made AEM Content Services compatible by having their Sling Model implement the `ComponentExporter` interface.

## Additional Resources

* [Getting Started with AEM Headless Tutorial](https://docs.adobe.com/content/help/en/experience-manager-learn/getting-started-with-aem-headless/overview.html)
* [AEM Headless Github Repository](https://github.com/adobe/aem-guides-wknd-mobile)
* [Hybrid CMS Demo on DemoHub](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-hybrid-cms.html)
