# Asset Share Commons

> Asset Share Commons (ASC) is a modern, open-source asset share reference implementation for AEM.
> Asset Share Commons is NOT supported as a product by Adobe Support.
>
> Note that Asset Share Commons can be used with ONLY an AEM Assets license, and does NOT require an AEM Sites license (even though it uses AEM Sites technologies).

![ASC - center](https://adobe-marketing-cloud.github.io/asset-share-commons/pages/images/hero.png)

## Download and Install

1. Download the <a href="https://github.com/Adobe-Marketing-Cloud/asset-share-commons/releases/latest" target="_blank">2 AEM packages for the latest version of the Asset Share Commons</a>.
    * asset-share-commons.ui.apps-x.x.x.zip (~10MB)
    * asset-share-commons.ui.content-x.x.x.zip (~75MB)
2. Upload and Install both packages to AEM Author via <a href="/crx/packmgr/index.jsp" x-cq-linkchecker="skip" target="_blank">AEM Package Manager</a>.
3. To demo on AEM Publish, both packages should be uploaded and installed on <a href="http://localhost:4503/crx/packmgr/index.jsp" x-cq-linkchecker="skip" target="_blank">AEM Publish as well via AEM Package manager</a>.


## Videos

* <a href="https://helpx.adobe.com/experience-manager/kt/assets/using/asset-share-commons-article-understand/asset-share-commons-feature-video-setup.html" target="_blank">Set up Asset Share Commons</a>
* <a href="https://helpx.adobe.com/experience-manager/kt/assets/using/asset-share-commons-article-understand/asset-share-commons-user-experience-feature-video-understand.html" target="_blank">Using Asset Share Commons</a>
* <a href="https://helpx.adobe.com/experience-manager/kt/assets/using/asset-share-commons-article-understand/asset-share-commons-feature-video-theming.html" target="_blank">Theming Asset Share Commons</a>


-------------------------------------------------------------------------------------------------------------------------------------------------------------------

## Demos

* [Asset Share Commons Demo](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-assets-asset-share-commons.html)

## Other materials

* [Asset Share Commons Website](https://adobe-marketing-cloud.github.io/asset-share-commons/)
* [Asset Share Commons Github Code Repository](https://github.com/Adobe-Marketing-Cloud/asset-share-commons)

* Videos
    * [Set up Asset Share Commons](https://helpx.adobe.com/experience-manager/kt/assets/using/asset-share-commons-article-understand/asset-share-commons-feature-video-setup.html)
    * [Using Asset Share Commons](https://helpx.adobe.com/experience-manager/kt/assets/using/asset-share-commons-article-understand/asset-share-commons-user-experience-feature-video-understand.html)
    * [Theming Asset Share Commons](https://helpx.adobe.com/experience-manager/kt/assets/using/asset-share-commons-article-understand/asset-share-commons-feature-video-theming.html)
    * [AEM Gems on Brand Portal and Asset Share Commons](https://docs.adobe.com/ddc/en/gems/Major-Brand-Portal-Release-and-new-reference-implementation-for-Asset-Share.html)
