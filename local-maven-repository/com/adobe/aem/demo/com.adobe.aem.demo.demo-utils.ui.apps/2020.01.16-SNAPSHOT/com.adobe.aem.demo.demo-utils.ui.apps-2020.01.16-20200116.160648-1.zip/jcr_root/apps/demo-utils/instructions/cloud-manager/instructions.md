# Cloud Manager for AEM

---

#### Cloud Manager for AEM is exclusive to Adobe Managed Services (AMS)

---

> Watch an overview of the Cloud Manager feature: (~5min)

<iframe width="854" height="480" src="https://www.youtube.com/embed/Vtf5ttdBc9k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> 

## Frictionless Upgrades with Cloud Manager (new 6.5)

> Watch an overview of Frictionless Upgrades with Cloud Manager (new feature): (~5min)
<iframe title="Adobe Video Publishing Cloud Player" width="854" height="480" src="https://video.tv.adobe.com/v/26322/?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen 
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

## Offline Cloud Manager Demo

> Please watch the [Understand Cloud Manager for AEM video series](https://helpx.adobe.com/experience-manager/kt/platform-repository/using/cloud-manager-feature-video-understand.html) (**7 videos**) as a walkthrough of how to talk about and use the Offline Cloud Manager. The OMC Cloud Manager does not perform the underlying actions, and not all functions in Cloud Manager work, so familiarize yourself with it prior to demoing

### Prerequisites

OMC Cloud Manager requires <a href="https://nodejs.org/en/" target="_blank">NodeJS 8.x.x</a> to be installed (one-time install.)

### Installation

1. To run the OMC Cloud Manager download the following based on your OS:
	* <a href="https://link.enablementadobe.com/omc-cloud-manager-macos" class="button" target="_blank">omc-cloudmanager-update-macos.tgz</a>
	* <a href="https://link.enablementadobe.com/omc-cloud-manager-windows" class="button" target="_blank">omc-cloudmanager-update-win.exe</a>
2. For macOS: Double-click start-cloud-manager.command, accepting any security prompts, and follow the instructions in the Terminal window.
3. For Windows: Double-click start-cloud-manager.bat, accepting any security prompts, and follow the instructions in the Command Prompt window.
4. Allow incoming connection for this application

### How to demo Frictionless Upgrades

1. Click on the **We.Retail Global** Managed Services - program.

    ![Managed Services - Program](./cloud-manager/images/we-retail-global.png)

2. From your Cloud Manager window, Click on the **Start Update** option
3. Perform the following actions
   1.  **Evaluation**
       1.  ***Product update report*** - The evaluation report provide valuable insights into your code, where new features may impact your application, and that you need to address before deploying the product update
           *  Click *Run Evaluation* - provides valuable insights into your code, where new features might impact your application, and that you need to address before deploying the product update
   2.  **Remediation**
       1.   ***Create branch branch*** - During the product update, you'll need to make changes to your code.Create a new branch where you'll do this. 
         *  *Click Create Branch*  and select the Branch Name as Update65
       2.  ***Run Code Quality Pipeline*** - Have you made code changes in your update branch to make it compatible with the AEM Update? if yes, you are ready to run the pipeline Cloud Manager has created to test the code quality on the update branch. You have to run the pipeline and clear code quality gates in order to advance to the next step. 
           1.  Click *Run Pipeline* and view details - Performs a code quality check on the update branch. Creates a new code quality non-production pipeline
               *   Pipeline type - Select the *Code Quality Pipe*
               *   Git Branch - *update65*
       3. ***Create Sandbox update environment*** - In this step your Sandbox update environment will be prepared and delivered to you by your CSE. You will be notified when you are ready to advance to the next step of the product update.
          * Click *Create sandbox environment*.
       4.  ***Run update pipeline*** - This step ensures that code changes in your update branch run in an upgraded environment. Cloud Manager has created an update pipeline that you can run to test and deploy code to your Sandbox update environment. Run it as many times as needed and clear all quality gates in order  to advance to the next step
           *  Click *Run Pipeline* and then view details
    3. **Execution**
       1. ***Create Stage Update Environment*** - In this step, the Stage update environment will be prepared and delivered to you by your CSE. You will be notified when you are ready to advance to the next step of the product update  
          * Click *Create Stage*
       2. ***Create Stage Update Environment*** - In this step, the Production update environment will be prepared and delivered to you by your CSE. You will be notified when you are ready to advance to the next step of the product update
          * Click *Create Stage*
    4. **Validation**
       1. ***Validate update environment*** - Run the update pipeline created by Cloud Manager to test and deploy code from the Stage update environment all the way to the Production update environment. You must run the update pipeline and clear all quality gates in order to advance to the next step of the product update.
          * Click *Run Pipeline* and view details
          * Approve the application request for Production deployment
    5. **Completion** - You now have the latest version of AEM Production environment running the latest code base.
   

### Other demos

Other features of Cloud Manager can be demoed using the Offline Cloud Manager including:

* Programs
* Environments
* Reports
* CI/CD Prodution Pipeline
* CI/CD Non-production pipeline
* Activity

See: [**Cloud Manager Video Series**](https://helpx.adobe.com/experience-manager/kt/platform-repository/using/cloud-manager-feature-video-understand.html)

## Other Materials
* [Cloud Manager CI/CD Pipeline - Feature Video](https://helpx.adobe.com/experience-manager/kt/platform-repository/using/cloud-manager-cicd-pipeline-feature-video-use.html)
* [Cloud Manager Demo](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-cloud-manager.html)

* Adobe Docs
  * [Cloud Manager User Guide](https://www.adobe.com/go/aem_cloud_mgr_userguide_en)
  * [Cloud Manager Documentation](https://www.adobe.io/apis/experiencecloud/cloud-manager/docs.html)
  * [Cloud Manager API Reference ](https://www.adobe.io/apis/experiencecloud/cloud-manager/api-reference.html)
  * [AEM Cloud Management](https://helpx.adobe.com/experience-manager/using/aem-cloud-management.html)