# AEM Assets Smart Tags

> Watch a quick intro video on Assets Smart Tags (~7 mins)

<iframe title="Adobe Video Publishing Cloud Player" width="854" height="480" src="https://video.tv.adobe.com/v/22254/?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen 
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

## Automatically set up Smart Tags

Click the buttons below to automatically set up the Smart Tags cloud service:

* The **Smart Tags cloud service**
* The **dam-update-service** key store
* Enables **Smart Tags** on all asset folders.
* **Automatically** Smart Tags on upload to AEM Assets.

<a href="/apps/demo-utils/instructions/smart-tags.install.html?region=na" class="button">Configure for North America</a>
<a href="/apps/demo-utils/instructions/smart-tags.install.html?region=emea" class="button">Configure for EMEA</a>
<a href="/apps/demo-utils/instructions/smart-tags.install.html?region=apac" class="button">Configure for APAC</a>

### Reset Smart Tagging and Training

Smart Tagging is now isolated to your specific AEM instance (not shared across demoers). Smart Tags for the AEM instance can be reset in the following ways:

* **Reset Tagging Status:** Once an asset is smart tagged, it cannot not be smart tagged again for 24 hours. Resetting the **tagging status** allows the asset to be smart tagged immediately.
* **Reset Training Status:** Once an asset has been trained for smart tagging, it cannot trained again for 24 hours. Resetting the **training status** allows the asset to be re-trainined immediately.
* **Full Reset of Training & Tagging:** Prior trainings are stored in the Adobe Cloud for this AEM instance. To reset all training, a full reset of Smart Tag training is required. This also resets the **training status** and **tagging status** for assets.

<a href="/apps/demo-utils/instructions/smart-tags.reset.html?tagging" class="button">Reset Tagging Status</a>
<a href="/apps/demo-utils/instructions/smart-tags.reset.html?training" class="button">Reset Training Status</a>
<a href="/apps/demo-utils/instructions/smart-tags.reset.html?all" class="button">Full Reset of Training & Tagging</a>

## Manually set up Smart Tags (all configurations support Training)

1. Open AEM Author and click <a href="/etc/cloudservices.html" target="_blank">Tools > Cloud Services > Legacy Cloud Services</a>
2. Click **Configure now** under Assets Smart Tags
3. Enter a Title and click **Create**
4. Enter the following configuration based on your geographical preference

    ### Configuration for North America

    ```plain
    Service URL : https://mc.adobe.io/marketingcloud/smartcontent
    Authorization Server : https://ims-na1.adobelogin.com
    Api Key : 691f65f597434342be3ec16052380b04
    Technical Account ID : CA092896592BBD490A495D28@techacct.adobe.com
    Organization ID : 218BFF5659280AF50A495D22@AdobeOrg
    Client Secret : 5cd48ae9-a51d-42c8-9aa7-ceb8b3bd7094
    ```

    #### Configuration for EMEA

    ```plain
    Service URL : https://mc.adobe.io/marketingcloud/smartcontent
    Authorization Server : https://ims-na1.adobelogin.com
    Api Key : 142648eb1a874352837882f038a13b2a
    Technical Account ID : B24ED851592BBDB00A495D25@techacct.adobe.com
    Organization ID : CBAFF3C959280C4B0A495E7B@AdobeOrg
    Client Secret : 8bd0f8de-bca9-4998-ae98-04b922c73bbc
    ```

    #### Configuration for APAC

    ```plain
    Service URL : https://mc.adobe.io/marketingcloud/smartcontent
    Authorization Server : https://ims-na1.adobelogin.com
    Api Key : b6a5e3672e8749ce992b1a369cdacf6d
    Technical Account ID : 43FF19775A6997270A495C95@techacct.adobe.com
    Organization ID : 7B493FE759719AAB0A495EEC@AdobeOrg
    Client Secret : a86f6617-80e1-4a3b-8e5d-6fac8e1bb121
    ```

5. Click **OK** to save Assets Smart Tags configuration.
6. Go to <a href="/libs/granite/security/content/useradmin.html" target="_blank">Tools > Security > Users</a> and click on user: **dam-update-service**
7. Click on **Create Key Store** and create one (any password is fine)
8. Once created, click **Manage Key Store > Add Private Key from Key Store File**  
  * Base on which geographic service you chose to integrate with above...
      * North America
         * New Alias: **similaritysearch**
         * Key file: [smart-tags-na-adobe-io.p12](/apps/demo-utils/resources/smart-tags/smart-tags-na-adobe-io.p12)
         * Keystore password: **test123**
         * Private key alias: **similaritysearch**
         * Set the private key password: **test123**
      * EMEA
        * New Alias: **similaritysearch**
        * Key file: [smart-tags-emea-adobe-io.p12](/apps/demo-utils/resources/smart-tags/smart-tags-emea-adobe-io.p12)
        * Keystore password: **test123**
        * Private key alias: **similaritysearch**
        * Set the private key password: **test123**
      * APAC
        * New Alias: **similaritysearch**
        * Key file: [smart-tags-apac-adobe-io.p12](/apps/demo-utils/resources/smart-tags/smart-tags-apac-adobe-io.p12)
        * Keystore password: **test123**
        * Private key alias: **similaritysearch**
        * Set the private key password: **test123**
9. Click **Submit**
10. Click **Save** in the top right

## Troubleshooting Smart Tags Training


1. Verify the Smart Tags configs are correct via the <strong><a  x-cq-linkchecker="skip" target="_blank" href="/system/console/jmx/com.day.cq.dam.similaritysearch.internal.impl%3Atype%3Dsimilaritysearch">Similarity Search JMX console</a> > validateConfigs() > Invoke</strong>. Ensure all response entries are successful.
2. The first time training is run for a tenant, it **MUST** be on two sets of images each with their OWN distinct tags. If that's not how the first training was executed, reset the tenant (using the buttons above) and re-train using this approach.
3. Create a new **[Smart Tags Training report](/mnt/overlay/dam/gui/content/reports/reportlist.html) > Create**. If the training report is empty for the trained tags, re-run the report every 5 minutes until there is report data for the applied tags. 

----

## Demos

* [Smart Tags](https://internal.adobedemo.com/content/demo-hub/en/demos/external/smart-tags-2-0.html)
* [Custom Smart Tags (with Training)](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-assets-custom-smart-tags.html)

## Other Materials

* Videos
    * [Smart Tags with Training Video](https://helpx.adobe.com/experience-manager/kt/assets/using/enhanced-smart-tags-feature-video-use.html)
    * [Set up Smart Tags with AEM Assets](https://helpx.adobe.com/experience-manager/kt/assets/using/smart-tags-technical-video-setup.html)
    * [Showing Smart Tags Scores](https://helpx.adobe.com/experience-manager/kt/assets/using/smart-tags-technical-video-setup.html#ShowingSmartTagsscoresforinstructionalpurposes)
    * [Understanding Smart Tags in AEM Assets](https://helpx.adobe.com/experience-manager/kt/assets/using/smart-tags-feature-video-understand.html)
* Adobe Docs
    * [Configuring Smart Tags](https://helpx.adobe.com/experience-manager/6-4/assets/using/config-smart-tagging.html)
    * [Smart Tags Training Guidelines](https://helpx.adobe.com/experience-manager/6-4/assets/using/smart-tags-training-guidelines.html)
    * [Enhanced Smart Tags](https://helpx.adobe.com/experience-manager/6-4/assets/using/enhanced-smart-tags.html#TrainingtheSmartContentService)
* Adobe Medium Blog post
    * [Efficient Asset Management with Enhanced Smart Tags](https://medium.com/adobetech/efficient-asset-management-with-enhanced-smart-tags-887bd47dbb3f)