# AEM Assets Visual Search (aka Find Similar)

> Since AEM 6.5 Service Pack 2

AEM Assets Visual Search, or Find Similar, leverages Adobe Sensei intelligence to locate image assets in the DAM that are visually similar to a selected image.

<iframe width="854" height="480" src="https://video.tv.adobe.com/v/29132/?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

Visual Search piggy backs on the AEM Assets Smart Tag integration. When an image asset is processed for Smart Tags buy the Adobe I/O Smart Content Services, not only does it write back the Smart Tag keywords, it also writes back special "feature vector" data, which is representation of the image as a mathematical vector (you can think to it as a point in space). Images having similar contents will be represented by vectors lying close in the vector space.

Note that Visual Search does NOT simply compare Smart Tag values (ie. the keywords applied by Smart Tags), but rather they compare images that have similar visual characteristics that are identified by Adobe Sensei, and uses advances mathematics to compare image compositions for similarities.

## Automatic Set up

1. Ensure <a href="/apps/demo-utils/instructions/smart-tags.html" target="_blank">Smart Tags</a> has been set-up.
1. <a href="/apps/demo-utils/instructions/visual-search.install.html" class="button">Auto-configure Visual Search</a>
2. (Re-)apply Smart Tags to any Assets that you want to user for OR show up as Visual Search results. Assuming AEM Demo Utils automatic Smart Tag set-up was used, all newly added assets will have the Visual Search metadata automatically applied.
    * AEM > Assets > Files > Select a Folder to process > Create > Workflow > DAM Smart Tag Assets
    * Upload new assets which will automatically processed with the Smart Tags workflow step.

## Manual Set up

The manual set up instructions are documented at [Adobe Docs > Search assets in AEM > Configuration and administration tasks related to search functionality > Visual or similarity search](https://helpx.adobe.com/experience-manager/6-5/assets/using/search-assets.html#configvisualsearch)

## How to Demo

1. Set up <a href="/apps/demo-utils/instructions/smart-tags.html" target="_blank">Smart Tags</a>
2. Set up Visual Search (see above)
3. Re-process assets to demo with the __DAM Smart Tags Assets__ workflow
    * AEM > Assets > Files > Select a Folder to process > Create > Workflow > DAM Smart Tag Assets
   Or upload new assets that will be automatically processed with the Smart Tags workflow step.
4. Wait for the Workflows to complete processing
5. In AEM Assets, select an (re-)processed Image asset, and click __Find Images_ in the top action bar (may be under the `...` on smaller screens)
6. See the similar images in Omnisearch results
5. Repeat step 5

----

## Other materials

* Adobe Docs
    * [Visual search manual set up instructions](https://helpx.adobe.com/experience-manager/6-5/assets/using/search-assets.html#configvisualsearch)
* Videos
    * [Use Visual Search](https://docs-stg.corp.adobe.com/content/help/en/experience-manager-learn/assets/metadata/use-visual-search.html)