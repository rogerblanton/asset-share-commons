# AEM Service Packs

> AEM Demo Utils is designed to run on the latest version of AEM. You may need to install a service pack to increment your local instance.

Please ensure the LATEST Service Pack is installed on your AEM instance for AEM Demo Utils to run properly.

The list of latest Service Packs can be found here:

* <a href="https://helpx.adobe.com/experience-manager/aem-releases-updates.html" target="_blank">AEM Release Updates</a>


## Verify current version

The current version of AEM can be verified by navigating to `AEM > Tools > Operations > System Overview` and reviewing the `Instance` section.

![AEM Version](./aem-service-packs/images/aem-version.png)

The 3rd dotted version number indicates the service pack level.

* `AEM 6.5.0` => AEM 6.5 with no Service Pack applied (aka GA)
* `AEM 6.5.1.0` => AEM 6.4 with Service Pack 1
* `AEM 6.5.2.0` => AEM 6.4 with Service Pack 2
* `AEM 6.5.3.0` => AEM 6.4 with Service Pack 3

