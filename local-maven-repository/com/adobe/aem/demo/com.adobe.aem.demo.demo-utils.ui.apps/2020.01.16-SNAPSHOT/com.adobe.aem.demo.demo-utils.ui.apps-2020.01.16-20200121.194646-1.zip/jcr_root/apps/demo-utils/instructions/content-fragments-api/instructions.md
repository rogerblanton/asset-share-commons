# AEM Content Fragments with Assets HTTP API

### AEM 6.5+ is required

> Watch an overview of the Content Fragments with Assets HTTP API feature: (~6min)

<iframe title="Adobe Video Publishing Cloud Player" width="854" height="480" src="https://video.tv.adobe.com/v/26390/?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen 
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

## Set up

1. Install AEM 6.5+
2. Create an account and download the Postman application from: <a href="https://www.getpostman.com/downloads/" target="_blank">https://www.getpostman.com/downloads/</a>
3. Download the Postman collection JSON file:
	* <a href="./content-fragments-api/resources/CRUD-CFM-API-We.Retail.postman_collection.json" class="button" target="_blank">CRUD-CFM-API-We.Retail.postman_collection.json</a>
4. In Postman click **Import** to import the JSON collection.

	![import collection](./content-fragments-api/images/import-json-collection.png)
5. The demo video explains some of the different features that can be demoed.
	
## Other materials

* <a href="https://git.corp.adobe.com/pages/CQ/dam-contentfragment/" target="_blank">Swagger API Reference (internal)</a> (A public reference will be released with 6.5 GA)


