<i class="aem-logo"></i>
<i class="adobe-logo"></i>

# Dynamic Media Hybrid (Legacy)

> Dynamic Media Hybrid is the "legacy" Dynamic Media integration.
> 
> The [**NEW** Dynamic Media integration](/apps/demo-utils/instructions/dynamic-media.html) is preferred.

## Install AEM 6.3 with Dynamic Media Hybrid enabled

1. Rename the quickstart jar to **cq-author-dynamicmedia-p4502.jar** and re/start AEM.
    * Or, alternatively, start from the command line with the runmodes flag: `java -jar cq-author-p4502.jar -r author,dynamicmedia`.
2. Verify that AEM started with the `dynamicmedia` runmode by checking [Tools > Operations > System Overview](/libs/granite/operations/content/systemoverview.html).
    ![System Overview](./dynamic-media-hybrid/images/system-overview.png)

## Automatically set up of Dynamic Media - Hybrid Cloud Service

Click the buttons below to automatically set up the Dynamic Media Cloud service.

<a href="/apps/demo-utils/instructions/dynamic-media-hybrid.install.html?region=na"  class="button">Configure for North America</a>
<a href="/apps/demo-utils/instructions/dynamic-media-hybrid.install.html?region=emea" class="button">Configure for EMEA</a>
<a href="/apps/demo-utils/instructions/dynamic-media-hybrid.install.html?region=apac" class="button">Configure for APAC</a>

## Manually set up Dynamic Media - Hybrid Cloud Service

1. Go to <a href="/etc/cloudservices.html" target="_blank">Tools > Deployment > Cloud Services</a>
2. Under **Adobe Marketing Cloud > Adobe Scene 7 > Dynamic Media Cloud Services**, tap **Configure Now**
3. Provide a **name** for the Cloud Service configuration (can be anything)
4. Tap **Create**

    For **North America**
    
    * Registration ID: 8ec87b10-c9d0-40f8-8f11-e164a27b2c76|demoCo
    * Video Service URL: https://gateway-na.assetsadobe.com/DMGateway/
    * Image Service URL: *LEAVE BLANK*
    
    For **EMEA**
    
    * Registration ID: f4378d8d-2fd4-4095-b449-ca7939f395d7|demoCo
    * Video Service URL: https://gateway-eu.assetsadobe.com/DMGateway/
    * Image Service URL: *LEAVE BLANK*
    
    For **APAC**
    
    * Registration ID: fa6a2806-a9db-4591-acd0-209 da70a73|demoCo
    * Video Service URL: https://gateway-ap.assetsadobe.com/DMGateway/
    * Image Service URL: *LEAVE BLANK*
    
5. Tap **OK** to save.

