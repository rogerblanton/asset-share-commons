<script type="text/javascript" src="/etc.clientlibs/clientlibs/granite/jquery.js"></script>
<script>

    $(function() {
        $('[data-action="with-redirect"]').click(function(e) {
            var el = $(this);
            e.preventDefault();

            $.getJSON('/libs/granite/csrf/token.json', function(csrf) {
                $.ajax(el.attr('href'), el.attr('method') || 'get', { ':cq_csrf_token': csrf.token }, function() {
                    window.open('/apps/demo-utils/instructions/install/success.html');
                }).fail(function() {
                    window.open('/apps/demo-utils/instructions/install/failure.html');
                });;
            });
        });

        $('[data-action="form"]').click(function(e) {
            var el = $(this);
            e.preventDefault();

            $.getJSON('/libs/granite/csrf/token.json', function(csrf) {
                var form = $('form');
                form.find('[name="\\:cq_csrf_token"]').val(csrf.token);
                form.attr('method', el.data('method') || 'post').attr('action', el.attr('href'));
                form.submit();
            });
        });

        setInterval(function() {
            $.getJSON('/libs/granite/csrf/token.json', function(csrf) {
                $.post('/.sampleassets.listUnsynced.json', {':cq_csrf_token': csrf.token}, function (data) {
                    var lines = data.split('\n'),
                        dmSampleCount = 0,
                        cssCount = 0;

                    $.each(lines, function (index, line) {
                        if (line.indexOf('/content/dam/_DMSAMPLE/') > -1) {
                            dmSampleCount++;
                        } else if (line.indexOf('/content/dam/_CSS/') > -1) {
                            cssCount++;
                        }
                    });

                    $('.dmSampleStatus').text(dmSampleCount);
                    $('.cssStatus').text(cssCount);

                }).fail(function (data) {
                    if (!data || data.indexOf('EofException') === -1) {
                        $('.dmSampleStatus').text('Dynamic Media is not configured');
                        $('.cssStatus').text('Dynamic Media is not configured');
                    }
                }).always(function () {
                    $.post('/.sampleassets.listUnactivated.json', {':cq_csrf_token': csrf.token}, function (data) {
                        var lines = data.split('\n'),
                            unActivatedCount = 0;

                        $.each(lines, function (index, line) {
                            if (line.trim() !== '') {
                                unActivatedCount++;
                            }
                        });

                        $('.unactivatedStatus').text(unActivatedCount);
                    }).fail(function (data) {
                        if (!data || data.indexOf('EofException') === -1) {
                            $('.unactivatedStatus').text('Dynamic Media is not configured');
                        }
                    });
                });
            })
        }, 5000);
    });
</script>

<form method="post" target="_blank"><input type="hidden" name=":cq_csrf_token"/></form>

<i class="aem-logo"></i>
<i class="adobe-logo"></i>

# Dynamic Media

---

### PLEASE BE PATIENT WITH THE DYNAMIC MEDIA SET UP!
### IT CAN TAKE UPWARDS TO AN HOUR TO SYNC ALL FILES TO SCENE 7

<h3 style="color:red">PLEASE DO NOT USE ACS BULK WORKFLOW MANAGER IN CONJUNCTION WITH DMS7. THERE IS A KNOWN BUG WITH ACS BWM THAT CAUSES AN IFINITE LOOP IN DMS7 PROCESSING.</h3>
---

> This is new and preferred Dynamic Media integration. This integration supersedes Dynamic Media Hybrid.

## 1. Start AEM with Dynamic Media (DMS7) enabled

1. Rename the quickstart jar to **cq-author-dynamicmedia_scene7-p4502.jar** and re/start AEM.
    * Or, alternatively, start from the command line with the run-modes flag: `java -jar cq-author-p4502.jar -r author,dynamicmedia_scene7`.
2. Verify that AEM started with the `dynamicmedia_scene7` run-mode by checking [Tools > Operations > System Overview](/libs/granite/operations/content/systemoverview.html).
    ![System Overview](./dynamic-media/images/system-overview.png)

---

### 2. Automatically set up of Dynamic Media Cloud Services

Click the button below to automatically set up the Dynamic Media Cloud service.

**AFTER CLICKING, BE PATIENT... you will be re-directed to a success or failure page when it's finished processing.**

<a href="/apps/demo-utils/instructions/dynamic-media.install.html?id=na" class="button">Configure for North America</a>

---

#### 3. Sync Status

**Syncing** refers to the pushing of resources and files to Scene 7 for processing. 

> Note you don't have to do anything...just wait!

Syncing is *required* for assets, viewers, artwork, etc. to work in the AEM Author preview environment.

*This table will automatically update every 5 seconds after Dynamic Media is configured... note the initial sync can take 15-30 mins to complete.*

<table>
<thead>
<tr>
<th>Files to sync to S7</th>
<th>Number of files left to sync</th>
</tr>
</thead>
<tbody>
    <tr>
        <td>
            /content/dam/_DMSAMPLE
        </td>
        <td>
            <span class="dmSampleStatus">Initializing...</span>
        </td>
    </tr>
    <tr>
        <td>
            /content/dam/_CSS/_OOTB
        </td>
        <td>
             <span class="cssStatus">Initializing...</span>
        </td>
    </tr>
</tbody>
</table>

For the exact paths pending sync, click the button below...

<a href="/.sampleassets.listUnsynced.json" class="button" data-action="form">List un-synced</a>
*A blank response for statuses is good! It means there are no un-synced/activated resources.*

Once the above table is all zero's... Proceed to the next section to activate the presets/CSS/artwork if required for the demo using the **Activate OOTB Presets, CSS and artwork** button below.

---

#### 4. Activation Status

**Activation** refers to the pushing fo resources and files to public Dynamic Media Delivery network. 

> Activation is only required **if** the assets will be serviced from the final, public URLs.


<table>
<thead>
<tr>
<th>Number of presets/CSS/artwork to activate</th>
</tr>
</thead>
<tbody>
    <tr>
        <td>
            <span class="unactivatedStatus">Initializing...</span>
        </td>
    </tr>
</tbody>
</table>

*This number should be ~323 when the syncing is complete, and the presets/CSS/artwork are ready to be activated.*

<a href="/.sampleassets.listUnactivated.json" class="button" data-action="form">List unactivated</a>
<a href="/.sampleassets.activateOotb.json" class="button" data-action="form">Activate OOTB Presets, CSS and artwork</a>

---

#### 5. Processing assets for Dynamic Media

> As part of Dynamic Media setup (starting in AEM 6.4 SP1) WE.Retail assets are automatically re-processed upon Dynamic Media configuration.

**The processing of all WE.Retail assets can take upwards to an hour! Be patient!**

There is no good way of checking the status of this process other than:

1. Navigate to [http://localhost:4502/system/console/slingevent](http://localhost:4502/system/console/slingevent)
2. Locate the section `Active JobQueue: Granite Transient Workflow Queue`
    * `Jobs` reports number of assets left to process.
    * `Finished Jobs` reports number of assets already processed.
    * (`Average Processing Time` x `Jobs`) / `Active Jobs` should give a rough estimate of the time left to process the remaining jobs.

<!--<a href="/.sampleassets.reprocessWeRetail.json" data-action="form">Re-process We.Retail assets</a>-->

---

#### 6. Demos and next steps

##### Checkout the [Smart Crop demo](/apps/demo-utils/instructions/smart-crop.html)!

Other Demo Resources:

* [Smart Crop Demo](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-assets-smart-crop.html)
* [Dynamic Media Live Demos](https://landing.adobe.com/en/na/dynamic-media/ctir-2755/live-demos.html)
* [See Adobe Demo Hub for the full collection of demos](http://demo.adobe.com/)

---

### Manually set up of Dynamic Media Cloud Services

1. Navigate to **AEM > Tools > Cloud Services**.
2. Click on **Dynamic Media Configuration** card.
3. Navigate into the **global** folder and tap **Create** in the top left.
4. Create a new Dynamic Media cloud configuration
    * Title: **Dynamic Media**
    * Email: **dynamicmedia-na@adobe.com**
    * Password: **$Dynamicna1**
    * Region: **North America - Enterprise**
    * Press `Connect to Dynamic Media`
    * Company: **DynamicMediaNA**
    * Company Root Folder Path: **DynamicMediaNA/**
        * *Do **not** change this value.*
    * Publish Assets: **Immediately**
    * Secure Preview Server: **https://preview1.assetsadobe.com**
        * *Do **not** change this value.*

    ![Cloud Config](./dynamic-media/images/cloud-config.png)


#### Special instructions

* **Publish Assets: Upon Activation**
    * During manual set up, if `Publish Assets: Upon Activation` is selected, you **must** wait 15 mins for the supporting assets to be published to and processed by Scene 7.
    * After waiting 15 mins, you must Publish any Image and Viewer presets at:
        * <a href="/mnt/overlay/dam/gui/content/s7dam/viewerpresets/viewerpresets.html" target="_blank">AEM > Tools > Assets > Viewer Presets</a>
        * <a href="/mnt/overlay/dam/gui/content/s7dam/imagepresets/imagepresets.html" target="_blank">AEM > Tools > Assets > Image Presets</a>
* Allow all Presets to publish before using. When `Publish Assets` is set to `Immediately`, they will automatically queue up to publish.


## Other materials

* [Understanding Dynamic Media with AEM Assets](https://helpx.adobe.com/experience-manager/kt/assets/using/dynamic-media-overview-feature-video.html)
* [Collection of AEM Assets Dynamic Media Videos](http://exploreadobe.com/dynamic-media-upgrade/)
* Adobe Docs
    * [Configuring Dynamic Media Scene7](https://helpx.adobe.com/experience-manager/6-4/assets/using/config-dms7.html)
    * [Managing Image Presets](https://helpx.adobe.com/experience-manager/6-4/assets/using/managing-image-presets.html)
    * [Managing Viewer Presets](https://helpx.adobe.com/experience-manager/6-4/assets/using/managing-viewer-presets.html)
    * [Troubleshooting Dynamic Media Scene7](https://helpx.adobe.com/experience-manager/6-4/assets/using/troubleshoot-dms7.html)
