# AEM SPA (Single Page App) Editor

---

### Features

* AEM's SPA Editor framework provides authors the ability to edit content for a Single Page Application (SPA). Developers using the framework create a SPA and then map areas of the SPA to AEM components, allowing authors to use familiar AEM Sites editing tools. The below videos shows authoring content for a SPA built using the React JS framework in AEM.

---

## Available Demos

* **[AEM SPA Editor - WKND Events](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-sites-spa-editor-framework.html)**
* **[We.Retail - React SPA Demo](https://internal.adobedemo.com/content/demo-hub/en/demos/external/weRetail_SPA_AEM_Demo.html)**

## WKND Events App - Setup

> Watch the demo and setup of the SPA Editor WKND Events: (~20min)

<iframe title="Adobe Video Publishing Cloud Player" width="854" height="480" src="https://video.tv.adobe.com/v/26393/?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen 
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

### Download and Install

1. Download:
	* <a href="https://link.enablementadobe.com/spa-editor-ui-apps" target="_blank" class="button">aem-guides-wknd-events.ui.apps.zip</a>
	* <a href="https://link.enablementadobe.com/spa-editor-ui-content" target="_blank" class="button">aem-guides-wknd-events.ui.content.zip</a>
2. Navigate to [AEM > Tools > Deployment > Packages](http://localhost:4502/crx/packmgr/index.jsp).
3. Click on **Upload Package**. Upload and Install the files from Step 1.
	* aem-guides-wknd-events.ui.apps-x.x.x.zip
	* aem-guides-wknd-events.ui.content-x.x.x.zip
4. Watch the demo video for more instructions on how to demo the capability.

## New! Editable Template Support

> In AEM 6.5 GA support for Editable Templates with the SPA Editor is available

To demo:

* For Angular: [http://localhost:4502/editor.html/conf/wknd-events/settings/wcm/templates/wknd-events-page-angular/structure.html](http://localhost:4502/editor.html/conf/wknd-events/settings/wcm/templates/wknd-events-page-angular/structure.html)
* For React: [http://localhost:4502/editor.html/conf/wknd-events/settings/wcm/templates/wknd-events-page-react/structure.html](http://localhost:4502/editor.html/conf/wknd-events/settings/wcm/templates/wknd-events-page-react/structure.html)

1. In **structure** mode add a simple text component above the main layout container:

	![Template add text component](./spa-editor/images/template-text-component.png)

2. Navigate to any of the content pages and you will see the fixed text component on all of them: i.e [http://localhost:4502/editor.html/content/wknd-events/react/home.html](http://localhost:4502/editor.html/content/wknd-events/react/home.html)

	![fixed component](./spa-editor/images/fixed-component.png)

## Front End Development

Front end developers will want to work outside of AEM using a local node server for rapid development. The content (JSON model) from AEM will be proxied into the application. 

To setup:

1. The following technologies and tools are needed to demo the React SSR capability locally:
	* [Java 1.8](http://www.oracle.com/technetwork/java/javase/downloads/index.html)
	* [Apache Maven](https://maven.apache.org/) (3.3.9 or newer)
	* [Node.js v10+](https://nodejs.org/en/)
	* [npm 6+](https://www.npmjs.com/)
2. Download and unzip the source:
	* <a href="https://link.enablementadobe.com/spa-editor-src" target="_blank" class="button">aem-guides-wknd-events-SRC.zip</a> 
3. Open a new terminal window and navigate to the root folder of the unzipped file from step 2.
4. Install the entire project with the following command:

```shell
$ mvn -PautoInstallPackage -Padobe-public clean install
```

5. In the terminal navigate to the sub-folder: `react-app`
6. Run the following command to start the local development server:

```shell
$ npm run start
```
	
7. Open a browser and navigate to [http://localhost:4502/aem/start.html](http://localhost:4502/aem/start.html), login as `admin:admin`.
8. In the **same** browser open a new tab and navigate to: [http://localhost:3000/content/wknd-events/react/home.html](http://localhost:3000/content/wknd-events/react/home.html)
9. Open the source code in an IDE like **Visual Studio Code**.
10. Make a change to a file like `<scr-code-location>demo-spa-editor-x.x.x/react-app/src/styles/_variables.scss` changing the primary color from yellow to blue (line 37):

	```diff
	- $color-primary:          $color-yellow;
	+ $color-primary: 			 blue;
	```
	
11. The browser should automatically refresh with the changes:

	![fed auto reload](./spa-editor/images/fed-auto-reload.gif)

12. The **content** is being proxied in directly from AEM. You can make changes to the content on the AEM side (http://localhost:4502) and see them reflected in the development server (http://localhost:3000).



## Server Side Rendering (SSR) Setup

> Note* that SSR is currently in a Technical Preview and only works for the **React** version of the app. Watch the demo video above (~17:00) to see how to demo.
 

1. The following technologies and tools are needed to demo the React SSR capability locally:
	* [Java 1.8](http://www.oracle.com/technetwork/java/javase/downloads/index.html)
	* [Apache Maven](https://maven.apache.org/) (3.3.9 or newer)
	* [Node.js v10+](https://nodejs.org/en/)
	* [npm 6+](https://www.npmjs.com/)
2. Download and unzip the source:
	* <a href="https://link.enablementadobe.com/spa-editor-src" target="_blank" class="button">aem-guides-wknd-events-SRC.zip</a> 
3. Open a new terminal window and navigate to the root folder of the unzipped file from step 2.
4. Install the entire project with the following command:

```shell
$ mvn -PautoInstallPackage -Padobe-public clean install
```

5. In the terminal navigate to the sub-folder: `<src-code-location>/demo-spa-editor-x.x.x/react-app`
6. Start the express server with the following command:
	
```shell
$ npm run start:server
```

7. Open a new browser and navigate to: [http://localhost:4502/content/wknd-events/react/home.html?wcmmode=disabled](http://localhost:4502/content/wknd-events/react/home.html?wcmmode=disabled)



## More Resources

#### Videos

1. [DemoHub Page](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-sites-spa-editor-framework.html)
2. [AEM SPA Editor Feature Video](http://helpx.adobe.com/experience-manager/kt/sites/using/spa-editor-framework-feature-video-use.html)
3. [AEM Gems SPA Editor Overview](https://helpx.adobe.com/experience-manager/kt/eseminars/gems/aem-spa-editor.html)
4. [SPA Editor SDK Deep Dive - React](https://helpx.adobe.com/experience-manager/kt/eseminars/gems/SPA-Editor-SDK-Deep-Dive-React.html)
5. [SPA Editor SDK Deep Dive - Angular](https://helpx.adobe.com/experience-manager/kt/eseminars/gems/SPA-Editor-SDK-Deep-Dive-Angular.html)

#### Documentation
1. [Getting Started with the AEM SPA Editor - WKND Events Tutorial](https://helpx.adobe.com/experience-manager/kt/sites/using/getting-started-spa-wknd-tutorial-develop.html)
2. [Single Page Application - Developer User Guide](https://helpx.adobe.com/experience-manager/6-4/sites/developing/user-guide.html?topic=/experience-manager/6-4/sites/developing/morehelp/spa.ug.js)