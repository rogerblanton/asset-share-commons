# AEM Assets Insights

> Watch an video of Asset Insights with Launch by Adobe: (~3min)

<iframe title="Adobe Video Publishing Cloud Player" width="854" height="480" src="https://video.tv.adobe.com/v/25943/?quality=9&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen 
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

## Performance data

This package automatically generates random Performance data for Clicks and Impressions. 

![Asset Insights - Performance](./asset-insights/images/performance.png)

The performance data is displayed in the graph at the bottom of any Asset's **Properties > Insights tab**. Performance data is generated automatically when this package is installed and does not require any other special activity (such as executing a Workflow) to take place.


## Usage and Summary data

This package provides a Workflow model that generates random Asset Insights Usage and Summary data for all assets in a folder (or sub-folders).

![Asset Insights - Score and Usage](./asset-insights/images/score-and-usage.png)

To generate Asset Insights Usage and Summary data, the **Generate Asset Insights Usage Data** must be executed against an Assets Folder.


1. Go to <a href="/assets.html/content/dam" target="_blank">Assets > Files</a> and select an Assets folder whose assets should have generated Usage and Summary data applied.
2. Select an Assets folder to apply the simulate Asset Insights data to.
3. In the top-left, tap **Create > Workflow**
5. Select **Generate Asset Insights Usage Data**
6. Tap **Start**
7. Open the Properties for any asset in the processed folder (or in any sub-folders)
8. Navigate to the Insights tab and the mock Summary and Usage data is visible

## Configurations

The ranges for both Performance and Usage data can be configured via OSGi configuration.

### Performance data configuration

![Asset Insights - OSGi Performance](./asset-insights/images/osgi-performance.png)

1. Go to the <a href="/system/console/configMgr/com.adobe.aem.demo.utils.assets.insights.impl.MockPerformanceDataServlet" target="aem-osgi" x-cq-linkchecker="skip">AEM OSGi Configuration Console</a>
2. Click on **AEM Demo Utils - Asset Insights - Mock Performance Data Servlet**
3. Configure the min and max values for the random performance data generation
	* **Min Clicks** 
		* Sets the minimum bound for Clicks
	* **Max Clicks**
		* Set the maximum bound for Clicks 
	* *Impressions will always be greater than Clicks, and be computed as (# of Clicks) + random number between min and max*
4. Click **Save** when complete
5. Performance data configuration changes will be reflected immediately on refresh of the Asset > Properties > Insights tab


### Usage and Summary data configuration

![Asset Insights - OSGi Usage](./asset-insights/images/osgi-usage.png)

1. Go to the <a href="/system/console/configMgr/com.adobe.aem.demo.utils.assets.insights.impl.MockAssetInsightsWorkflowProcess" target="aem-osgi" x-cq-linkchecker="skip">AEM OSGi Configuration Console</a>
2. Click on **AEM Demo Utils - Asset Insights - Usage and Summary Performance Generator**
3. Configure the min and max values for the random summary and usage data generation
	* **Min Usage** 
		* Sets the minimum bound for any given Usage score
	* **Max Usage**
		* Sets the maximum bound for any given Usage score
	* **Min Performance Clicks** 
		* Sets the minimum bound for Clicks summary score
	* **Max Performance Clicks**
		* Set the maximum bound for Clicks summary score
	* **Min Performance Impressions** 
		* Sets the minimum bound for Impressions summary score
	* **Max Performance Impressions**
		* Set the maximum bound for Impressions summary score 
4. Click **Save** when complete
5. Usage and Summary data is not reflected immediately and the **Generate Asset Insights Usage Data** must be run again over assets to use the newly configured values.

----

## Demos

* [AEM Assets - Assets Insights Demo Script](https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-assets-insights-6-3.html)

## Other materials

* Videos
	* [Set up Asset Insights with AEM Assets with Launch by Adobe](https://helpx.adobe.com/experience-manager/kt/assets/using/asset-insights-launch-tutorial-setup.html)	 
    * [Set up Asset Insights with AEM Assets (DTM)](https://helpx.adobe.com/experience-manager/kt/assets/using/asset-insights-tutorial-setup.html) *Note Launch is preferred Tag Management going forward*
* Adobe Docs
    * [Asset Insights](https://helpx.adobe.com/experience-manager/6-4/assets/using/touch-ui-asset-insights.html)
    * [Configuring Assets Insights](https://helpx.adobe.com/experience-manager/6-4/assets/using/touch-ui-configuring-asset-insights.html)