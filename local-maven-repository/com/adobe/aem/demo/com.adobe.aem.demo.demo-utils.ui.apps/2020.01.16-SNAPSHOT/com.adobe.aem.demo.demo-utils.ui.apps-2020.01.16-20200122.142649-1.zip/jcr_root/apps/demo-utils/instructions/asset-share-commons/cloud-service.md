## Set up Instructions

1. Clone the "All Demos" Git repository (requires access to Adobe VPN and [https://git.corp.adobe.com](https://git.corp.adobe.com/aem-technical-marketing/com.adobe.aem.demos.all-demos))
    + `$ git clone git@git.corp.adobe.com:aem-technical-marketing/com.adobe.aem.demos.all-demos.git`
2. Follow [these video instructions](https://docs.adobe.com/content/help/en/experience-manager-cloud-service/implementing/deploying/overview.html#introduction) on how to push the code base to your AEM as a Cloud Service Git repository and deploy to your Environment.
