<i class="aem-logo"></i>
<i class="adobe-logo"></i>

# AEM Demo Utils Bulk Set up

This console allows for multiple demo resources to be set up at once.

Select the options to automatically set up, and press the **Set up** button below.

Some demo resources may require other manual steps. Please only use this UI if you understand how the discrete set ups work.

## Bulk set up

<form method="get" action="/apps/demo-utils/instructions/bulk-setup.install.html">

<label for="region"><strong>Region</strong></label>
<select name="region">
    <option value="na" selected>North America</option>
    <option value="emea">EMEA</option>
    <option value="apac">APAC</option>
</select>

<dl>

<dt>Automatic configurations</dt>

<dd>
    <input type="checkbox" id="adobe-stock" name="adobe-stock" value="install" checked/>
    <label for="adobe-stock">Adobe Stock integration</label>
</dd>

<!--
<dd>
    <input type="checkbox" id="smart-tags" name="smart-tags" value="install" checked/>
    <label for="smart-tags">Smart Tags</label>
</dd>
-->

<dd>
    <input type="checkbox" id="visual-search" name="visual-search" value="install" checked/>
    <label for="visual-search">Visual Search (aka Find Similar Images) <em>(requires Smart Tags)</em></label>
</dd>

<!--
<dd>
    <input type="checkbox" id="smart-translation-search" name="smart-translation-search" value="install" checked/>
    <label for="smart-translation-search">Smart Translation Search</label>
</dd>
-->

<dd>
    <input type="checkbox" id="adobe-asset-link" name="adobe-asset-link" value="install"/>
    <label for="adobe-asset-link">Adobe Asset Link <em>(requires one-time manual extension set up)</em></label>
</dd>


<!--<dt><em>Pick only one Dynamic Media type (DMS7 vs. DM Hybrid)</em></dt>-->

<dd>
    <input type="checkbox" id="dynamic-media-scene7" name="dynamic-media-scene7" value="install"/>
    <label for="dynamic-media-scene7">Dynamic Media (DMS7)</label>
</dd>

<!--
<dd>
    <input type="checkbox" id="dynamic-media-hybrid" name="dynamic-media-hybrid" value="install"/>
    <label for="dynamic-media-hybrid" style="color: #ccc">Dynamic Media Hybrid (Deprecated)</label>
</dd>
-->

<dt>Automatic actions</dt>

<dd>
    <input type="checkbox" id="asset-insights" name="asset-insights" value="apply" checked/>
    <label for="asset-insights">Generate Asset Insights <em>(for all assets)</em></label>
</dd>

<dd>
    <input type="checkbox" id="inbox-tasks" name="inbox-tasks" value="apply" checked/>
    <label for="inbox-tasks">Generate Inbox Tasks <em>(using assets as payloads)</em></label>
</dd>

</dl>

<input type="submit" value="Set up" class="button"/>
</form>