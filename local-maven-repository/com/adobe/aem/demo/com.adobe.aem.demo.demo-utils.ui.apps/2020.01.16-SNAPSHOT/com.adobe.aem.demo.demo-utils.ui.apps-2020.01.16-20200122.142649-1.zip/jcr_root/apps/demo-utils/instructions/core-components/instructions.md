# AEM Core Component Showcase and Library

### AEM 6.4.2+ is required

> Watch an overview of the Core Component Showcase and Component Library: (~12min)

<iframe title="Adobe Video Publishing Cloud Player" width="854" height="480" src="https://video.tv.adobe.com/v/26311/?quality=12&autoplay=false&hidetitle=true&marketingtech.adobe.analytics.additionalAccounts=tmdtmdaemdemoutilsprod" frameborder="0" webkitallowfullscreen 
mozallowfullscreen allowfullscreen scrolling="no"></iframe>

AEM Core Components are a set of standardized components for AEM 6.3+ that can be used to speed up development of websites.

Hosted on GitHub: [https://github.com/adobe/aem-core-wcm-components](https://github.com/adobe/aem-core-wcm-components)



## Core Component Library

This is a library that can be bundled with AEM starter projects. It serves to show examples of each Core Component.

![Component Library Screenshot](./core-components/images/component-library.png)

### Value Proposition

* Allows a marketer to quickly learn and experiment with the core component functionality and features
* Allows a Front-End Developer to easily see the generated markup in order to create style and brand variations
* Allows an AEM Developer to see how the core components are expected to be used.

### How to Use

* Is embedded with AEM Quickstart in 6.5, will be installed with the Core Component Showcase below.
* Navigate to: [http://localhost:4502/editor.html/content/core-components-examples/library.html](http://localhost:4502/editor.html/content/core-components-examples/library.html)

### See it in action

* [http://opensource.adobe.com/aem-core-wcm-components/library.html](http://opensource.adobe.com/aem-core-wcm-components/library.html)


## Core Component Showcase

The AEM Sites Core Component Showcase is a build out of ficticious website designs, each website comprised of 3 mocked up page types, using only Core Components (or as it turns only, MOSTLY Core Components).

The sites are built using AEM's latest technologies:

* Core Components
* Style System
* Editable Templates
* Reponsive Grid
* NPM ClientLibrary Module

..and each page is configured to be responsive to Desktop, Tablet and Mobile views.

### Value proposition

The Core Component Showcase sites demonstrate real-life build out of website designs using mostly Core Components, and front-end development work (CSS and JavaScript) to style the Core Components to attain these varying designs.

Targeting Core Components' stable HTML structure and consisent CSS class naming, front-end developers can use tools they know and love (we used **Webpack** and **SCSS**) to skin and style Core Components to meet most design requirements.

It's worth noting that the front-end assets were developed using the usual, AEM-agnostic front-end development tools:

* Node/NPM Modules
* Yarn
* Webpack
* SCSS
* Babel

The AEM ClientLibrary NPM Module was used to build this front-end project and automatically package and deploy it as an AEM ClientLibrary.

### How to use

1. Download the Core Component Showcase packages:
	* <a href="https://link.enablementadobe.com/showcase-ui-apps" class="button" target="_blank">showcase.ui.apps.zip</a>
	* <a href="https://link.enablementadobe.com/showcase-ui-content" class="button" target="_blank">showcase.ui.content.zip</a>
2. Install the latest Core Components Showcase packages (`showcase.ui.apps.x.x.x.zip` and `showcase.ui.content.x.x.x.zip`) on AEM 6.4 GA or later.
3. Navigate to AEM > Sites > Core Component Showcase and `Edit` the built out pages (see the section below).
	* Note, **not all pages are built out**.
4. Edit the built out pages (see list below) and show how the Core Components can be authored (added/removed) and their appearance is dictated via the Style brush.
![Style Brush](./core-components/images/style-brush.png)
5. View the pages as published, editting the page and selecting `Page Properties > View Page as Published` to enable special effects like parallax scrolling.

<p><a href="https://internal.adobedemo.com/content/demo-hub/en/demos/external/aem-sites-core-component-showcase.html" target="_blank" class="button">View on DemoHub</a> </p>

### The Palms of Aruba: A Hospitality website

#### Home page design

[http://localhost:4502/sites.html/content/showcase/en/hospitality](/sites.html/content/showcase/en/hospitality)

![Home - Final](./core-components/images/hospitality__home.png)

#### Content page design

[http://localhost:4502/sites.html/content/showcase/en/hospitality/stay](/sites.html/content/showcase/en/hospitality/stay)

![Stay - Final](./core-components/images/hospitality__stay.png)

#### Auxillary content page design

[http://localhost:4502/sites.html/content/showcase/en/hospitality/about](/sites.html/content/showcase/en/hospitality/about)

![About Us - Final](./core-components/images/hospitality__about.png)

#### The custom components

The **only** custom AEM components used to build out these 3 pages are:

* The sticky header
* The booking widget
* The Google maps widget

..and are circled in pink in the image below.

![Custom Components - Final](./core-components/images/hospitality__custom-components.png)

## Pinnacle Finance: Financial Services Institute website

### Home page design

[http://localhost:4502/editor.html/content/showcase/en/finance.html](http://localhost:4502/editor.html/content/showcase/en/finance.html)

![Home - Final](./core-components/images/fsi_home.png)

### Financial Tools

[http://localhost:4502/editor.html/content/showcase/en/finance/tools.html](/editor.html/content/showcase/en/finance/tools.html)

![Tools - Final](./core-components/images/fsi_tools.png)

### Financial Resources

[http://localhost:4502/editor.html/content/showcase/en/finance/resources.html](/editor.html/content/showcase/en/finance/resources.html)

![Resources - Final](./core-components/images/fsi_resources.png)

### The custom components

The **only** custom AEM components used to build out these 3 pages are:

* The sticky header - which contains Navigation core component

![Custom Components - Final](./core-components/images/fsi_customcomponents.png)

### See it in action

* [https://aem.enablementadobe.com/content/showcase/en/hospitality.html](https://aem.enablementadobe.com/content/showcase/en/hospitality.html)
* [https://aem.enablementadobe.com/content/showcase/en/finance.html](https://aem.enablementadobe.com/content/showcase/en/finance.html)
