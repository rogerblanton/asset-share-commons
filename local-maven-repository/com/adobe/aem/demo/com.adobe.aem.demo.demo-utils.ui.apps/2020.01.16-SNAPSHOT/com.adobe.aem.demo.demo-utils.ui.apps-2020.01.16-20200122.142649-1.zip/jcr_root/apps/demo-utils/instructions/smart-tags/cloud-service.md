### Set up

Smart Tags are automatically setup and provisioned on AEM as a Cloud Service instances. There is nothing to configure.

Just upload new image assets to AEM Assets and they will automatically be smart tagged.

### Smart Tag Training

TO

### Reset Smart Tagging and Training

Smart Tagging is now isolated to your specific AEM instance (not shared across demoers). Smart Tags for the AEM instance can be reset in the following ways:

* **Reset Tagging Status:** Once an asset is smart tagged, it cannot not be smart tagged again for 24 hours. Resetting the **tagging status** allows the asset to be smart tagged immediately.
* **Reset Training Status:** Once an asset has been trained for smart tagging, it cannot trained again for 24 hours. Resetting the **training status** allows the asset to be re-trainined immediately.
* **Full Reset of Training & Tagging:** Prior trainings are stored in the Adobe Cloud for this AEM instance. To reset all training, a full reset of Smart Tag training is required. This also resets the **training status** and **tagging status** for assets.

<a href="/apps/demo-utils/instructions/smart-tags.reset.html?tagging" class="button">Reset Tagging Status</a>
<a href="/apps/demo-utils/instructions/smart-tags.reset.html?training" class="button">Reset Training Status</a>
<a href="/apps/demo-utils/instructions/smart-tags.reset.html?all" class="button">Full Reset of Training & Tagging</a>

## Troubleshooting Smart Tags Training

1. The first time training is run for a tenant, it **MUST** be on two sets of images each with their OWN distinct tags. If that's not how the first training was executed, reset the tenant (using the buttons above) and re-train using this approach.
1. Create a new **[Smart Tags Training report](/mnt/overlay/dam/gui/content/reports/reportlist.html) > Create**. If the training report is empty for the trained tags, re-run the report every 5 minutes until there is report data for the applied tags.

