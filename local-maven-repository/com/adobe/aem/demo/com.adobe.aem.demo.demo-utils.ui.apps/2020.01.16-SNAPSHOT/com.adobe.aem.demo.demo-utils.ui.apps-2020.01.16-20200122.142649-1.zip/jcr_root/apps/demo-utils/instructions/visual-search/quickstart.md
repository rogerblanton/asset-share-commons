## How to Demo on AEM as a Cloud Service SDK's Quickstart Jar

*Smart Tags is automatically setup on on AEM as a Cloud Service environments*

1. Re-process assets to demo with the __DAM Smart Tags Assets__ workflow
    * AEM > Assets > Files > Select a Folder to process > Create > Workflow > DAM Smart Tag Assets
   Or upload new assets that will be automatically processed with Smart Tags.
2. Wait for the asses to complete Processing
3. In AEM Assets, select an (re-)processed Image asset, and click __Find Images_ in the top action bar (may be under the `...` on smaller screens)
4. See the similar images in Omnisearch results
5. Repeat Step 3 -> 5