## AEM as a Cloud Service Set up

Asset Share Commons is included as part of the All Demos project that can be deployed to AEM as a Cloud Service environments via Cloud Manager.

By virtue of having Demo Utils installed on AEM as a Cloud Service, means that Asset Share Commons is also installed.

* [Go to the Asset Share Commons Demo sites](/sites.html/content/asset-share-commons/en)

