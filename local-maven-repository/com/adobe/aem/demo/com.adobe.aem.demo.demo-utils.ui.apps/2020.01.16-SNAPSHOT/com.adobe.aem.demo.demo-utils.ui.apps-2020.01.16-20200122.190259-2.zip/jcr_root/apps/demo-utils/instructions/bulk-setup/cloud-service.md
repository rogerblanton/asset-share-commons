<form method="get" action="/apps/demo-utils/instructions/bulk-setup.install.html">

<label for="region"><strong>Region</strong></label>
<select name="region">
    <option value="na" selected>North America</option>
    <option value="emea">EMEA</option>
    <option value="apac">APAC</option>
</select>

<dl>

<dt>Automatic configurations</dt>

<dd>
    <input type="checkbox" id="adobe-asset-link" name="adobe-asset-link" value="install"/>
    <label for="adobe-asset-link">Adobe Asset Link <em>(requires one-time manual extension set up)</em></label>
</dd>

<dt>Automatic actions</dt>

<dd>
    <input type="checkbox" id="asset-insights" name="asset-insights" value="apply" checked/>
    <label for="asset-insights">Generate Asset Insights <em>(for all assets)</em></label>
</dd>

<dd>
    <input type="checkbox" id="inbox-tasks" name="inbox-tasks" value="apply" checked/>
    <label for="inbox-tasks">Generate Inbox Tasks <em>(using assets as payloads)</em></label>
</dd>

</dl>

<input type="submit" value="Set up" class="button"/>
</form>