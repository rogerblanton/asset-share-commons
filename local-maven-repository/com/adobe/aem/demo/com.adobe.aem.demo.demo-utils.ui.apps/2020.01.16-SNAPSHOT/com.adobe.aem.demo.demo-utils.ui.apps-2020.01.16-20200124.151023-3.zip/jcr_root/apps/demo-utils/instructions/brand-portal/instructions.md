Brand Portal is currently not supported by AEM as a Cloud Service.

As an interim alternative, please review [Asset Share Commons](/apps/demo-utils/instructions/asset-share-commons.html).