Sending e-mail from AEM as a Cloud Service is currently NOT  supported.

This effects a variety of feature such as:

* AEM Assets Asset Link Share
* Workflow e-mail notifications
* Asset Share Commons sharing capability
* etc.

<!-- QUICKSTART_INSTRUCTIONS -->