<video width="100%" controls>
  <source src="https://s7d9.scene7.com/is/content/AdobeDemoLab/aem-branding-wizard/BW_Commercial.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video>

Visit the [Branded Experiences demo.adobe.com page](https://internal.adobedemo.com/content/demo-hub/en/demos/external/branded-experiences.html) for the latest instructions and installers.

*Note that Branded Experiences ONLY works on the local AEM as a Cloud Service Quickstart Jar (which you are on now) and NOT on a true AEM as a Cloud Service environment (in the Adobe Cloud).*