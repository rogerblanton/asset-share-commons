
This effects a variety of feature such as:

* AEM Assets Asset Link Share
* Workflow e-mail notifications
* Asset Share Commons sharing capability
* etc.

<!-- CLOUD-SERVICE_INSTRUCTIONS -->

<!-- QUICKSTART_INSTRUCTIONS -->

<!-- 65_INSTRUCTIONS -->

