Everything appears to have been automatically configured correctly.

Please <a href="javascript:window.close();">close this window</a> and and verify the configured was effective.

It's possible we didn't detect a problem so make sure everything is working. If there's an issue try the automated steps again, or you can always fallback to the manual steps.

<br/>

<a href="javascript:window.history.back();" class="button">Go back</a> <a href="javascript:window.close();" class="button">Close window</a>
