## Cloud set up

Currently CIF is only supported on **AEM 6.5+**. Support for AEM as a Cloud Service is expected **~July 2020**.

Install Demo Utils on AEM 6.5+ for instructions on how to demo CIF on AEM 6.5.