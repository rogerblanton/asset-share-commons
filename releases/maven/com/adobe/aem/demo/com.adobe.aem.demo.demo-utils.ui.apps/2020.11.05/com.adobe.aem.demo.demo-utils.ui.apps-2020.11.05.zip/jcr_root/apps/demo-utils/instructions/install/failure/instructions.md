Something went wrong during the automatic configuration.

Please <a href="javascript:window.close();">close this window</a> and try the **manual set up instructions** if they exist. 

Please report this issue to <a href="mailto:Grp-AEMTechMarketing@adobe.com">Grp-AEMTechMarketing@adobe.com</a> or leave a message on the [demo.adobe.com](http://demo.adobe.com) forums.

<br/>

<a href="javascript:window.history.back();" class="button">Go back</a> <a href="javascript:window.close();" class="button">Close window</a>
