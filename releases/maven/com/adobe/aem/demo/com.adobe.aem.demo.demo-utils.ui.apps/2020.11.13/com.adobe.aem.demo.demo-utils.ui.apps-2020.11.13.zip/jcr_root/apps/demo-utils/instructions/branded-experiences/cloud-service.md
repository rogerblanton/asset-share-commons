<div class="unsupported">
Branded Experiences is not supported on AEM as a Cloud Service, and can ONLY be run via a local AEM as a Cloud Service QuickStart Jar.
</div>