Branded Experiences is a tool that allows for quick and easy creation of AEM Demos with customer branded sites and mobile applications. It lets you demonstrate AEM as a Cloud Service features like Layout mode, Experience Fragments, Content Fragments, Translation Management and AEM Mobile.

<!-- CLOUD-SERVICE_INSTRUCTIONS -->

<!-- QUICKSTART_INSTRUCTIONS -->

<!-- 65_INSTRUCTIONS -->