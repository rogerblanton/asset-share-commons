This console allows for multiple demo resources to be set up at once.

Select the options to automatically set up, and press the **Set up** button below.

Some demo resources may require other manual steps. Please only use this UI if you understand how the discrete set ups work.

Note that different features can be automatically set up on different environment types. AEM as a Cloud Service (in the Cloud) being the most strict, and prevents many automatic setups from being available.

---

 <!-- CLOUD-SERVICE_INSTRUCTIONS -->

 <!-- QUICKSTART_INSTRUCTIONS -->
 
  <!-- 65_INSTRUCTIONS -->