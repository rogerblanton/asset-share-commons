## Cloud set up

Core Components Showcase is included as part of the All Demos project that can be deployed to AEM as a Cloud Service environments via Cloud Manager.

By virtue of having Demo Utils installed on AEM as a Cloud Service, means that Core Components Showcase is also installed.

* [Go to the Core Components Showcase sites](/sites.html/content/showcase/en)
