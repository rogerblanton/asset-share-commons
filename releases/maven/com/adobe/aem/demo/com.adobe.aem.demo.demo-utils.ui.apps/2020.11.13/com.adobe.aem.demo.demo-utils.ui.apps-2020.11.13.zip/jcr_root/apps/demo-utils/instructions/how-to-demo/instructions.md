AEM Demo Utils can be used to expedite the demoing of AEM as a Cloud Service by providing:

+ List of common features to demo
+ Instructions on how to set up feature and how to demo them
+ Some features have automatic set-up using shared Demo credentials provided by Demo Utils project

<!-- CLOUD-SERVICE_INSTRUCTIONS -->

<!-- QUICKSTART_INSTRUCTIONS -->

<!-- 65_INSTRUCTIONS -->
