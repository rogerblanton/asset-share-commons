
Smart Tags is automatically provisioned on AEM as a Cloud Service environments.

## Smart Tags existing assets

* Once Smart Tags has been configured, Smart Tag any existing assets by selecting either Assets or Assets Folders, and tapping the `Reprocess Assets` button in the top action bar.
    ![Reprocess assets](./smart-tags/images/reprocess-assets.png)

