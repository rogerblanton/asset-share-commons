<div class="unsupported">
Smart Translation Search is currently not supported by AEM as a Cloud Service.
</div>