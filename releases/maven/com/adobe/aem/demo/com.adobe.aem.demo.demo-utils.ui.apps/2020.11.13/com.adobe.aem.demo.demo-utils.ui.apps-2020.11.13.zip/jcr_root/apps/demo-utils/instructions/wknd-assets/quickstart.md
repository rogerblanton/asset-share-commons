## Installation instructions

The WKND Assets package can be installed on the local AEM SDK Quickstart Jar using AEM's Package Manager.

+ [damdemo.all.x.x.x.zip](https://link.enablementadobe.com/wknd-assets__aem-package)
